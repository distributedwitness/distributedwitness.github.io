<?php

/**
 * Team Shortcode
 */


// [progression_team heading_pro="" menu_description_pro="" etc...]
add_shortcode( 'progression_team', 'progression_team_func' );
function progression_team_func( $atts, $content = null ) { // New function parameter $content is added!
   extract( shortcode_atts( array(
	  'team_columns' => '3',
	  'team_post_count' => '9',
	  'team_pagination' => 'pagination_off',
	  'team_sorting_pro' => '',
	  'property_filter_categories' => '',
	  'team_filter_text' => 'All',
		'team_padding' => '0',
		  
	  
   ), $atts ) );
   
    $output_pro = '';
	
	STATIC $idpro = 0;
	$idpro++;
	
	ob_start();
	?>
	
	
	
	<?php
	if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } else if ( get_query_var('page') ) {   $paged = get_query_var('page'); } else {  $paged = 1; }
	global $blogloop;
	global $post;
	
	
	$postIds = $property_filter_categories; // get custom field value
    $arrayIds = explode(',', $postIds); // explode value into an array of ids
    if(count($arrayIds) <= 1) // if array contains one element or less, there's spaces after comma's, or you only entered one id
    {
        if( strpos($arrayIds[0], ',') !== false )// if the first array value has commas, there were spaces after ids entered
        {
            $arrayIds = array(); // reset array
            $arrayIds = explode(', ', $postIds); // explode ids with space after comma's
        }
    }
	 
	 
 	if ( $property_filter_categories ) {
 	   	$blogloop = new WP_Query(
 	   		array(
 	   	   'post_type' => 'team',
 	   	   'posts_per_page' => $team_post_count,
 				'paged' => $paged,
 				'tax_query' => array(
 				        // Note: tax_query expects an array of arrays!
 				        array(
 				            'taxonomy' => 'team-category', // 
 				            'field'    => 'slug',
 				            'terms'    => $arrayIds
 				        )
 				 ),
 	   		)
 	    );
 	}
	else {

	$blogloop = new WP_Query(
		array(
	        'post_type' => 'team',
	        'posts_per_page' => $team_post_count,
			  'paged' => $paged
		)
	);
	}
	
	?>

	
	<div class="progression-team">
	<div class="team-pro-visual-composer">
		
		<?php if($team_sorting_pro == 'true' ): ?>
		<ul class="filter-button-group port-filter-group-<?php echo esc_attr($idpro) ?> button-grou">
			<?php if($property_filter_categories): ?>
			
				<?php
					$i = 0;

					$args = array(
					    'hide_empty'             => '0',
					    'slug'              => $arrayIds,
					); 
				
					$terms = get_terms( 'team-category', $args );
					if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
						echo '<li class="is-checked" data-filter="*">' . $team_filter_text .'</li> ';	
				
						foreach ( $terms as $term ) { 
						if ($i == 0) {
						echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
						} else if ($i > 0)  {
						echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
						}
						$i++;
						}
					}	
				?>
			<?php else: ?>
				<?php
					$i = 0;
					$terms = get_terms( 'team-category', 'hide_empty=0' );
					if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
						echo '<li class="is-checked" data-filter="*">' . $team_filter_text .'</li> ';	
				
						foreach ( $terms as $term ) { 
						if ($i == 0) {
						echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
						} else if ($i > 0)  {
						echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
						}
						$i++;
						}
					}	
				?>
			<?php endif ?>		
		</ul>
		<div class="clearfix-pro"></div>
		<?php endif ?>
		
		<div class="progression-masonry<?php echo esc_attr($idpro) ?>" style="margin-right:<?php echo esc_attr($team_padding) / 4 ?>%; margin-left:<?php echo esc_attr($team_padding) / 4 ?>%;">
			
		<?php  $col_count_progression = $team_columns;
		while($blogloop->have_posts()): $blogloop->the_post();
				?>		
				<div class="progression-masonry-item progression-masonry-col-<?php echo esc_attr($team_columns) ?> <?php  $terms = get_the_terms( $post->ID , 'team-category' );  if ( !empty( $terms ) ) : 	foreach ( $terms as $term ) { 	$term_link = get_term_link( $term, 'team-category' ); if( is_wp_error( $term_link ) ) continue; echo " ". $term->slug ; }  endif; ?>">
							
					<div class="progression-masonry-inline-padding" style="padding:<?php echo esc_attr($team_padding) ?>%;">
						<div class="invested-team-border">
					<?php include(locate_template('template-parts/content-team-vc.php')); ?>
					</div>
					</div>
				</div><!-- close event columns -->
		<?php endwhile; // end of the loop. ?>
		<div class="clearfix-pro"></div>
		
		</div><!-- close .progression-masonry -->
	</div><!-- close .property-pro-visual-composer -->
	</div><!-- .progression-team -->
	
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		'use strict';
		
		/* Default Isotope Load Code */
		var $container = $('.progression-masonry<?php echo esc_attr($idpro) ?>').isotope();
		$container.imagesLoaded( function() {
			$(".progression-masonry-item").addClass('opacity-progression');
			$container.isotope({
				itemSelector: '.progression-masonry-item',
				transitionDuration: '0.4s',

				masonry: {
				    columnWidth: '.progression-masonry-col-<?php echo esc_attr($team_columns) ?>',
				},hiddenStyle: {
					opacity: 0
				},
				visibleStyle: {
					opacity: 1
				}
	 		});
		});
		/* END Default Isotope Code */
		
		
		<?php if($team_sorting_pro == 'true' ): ?>
		$('.port-filter-group-<?php echo esc_attr($idpro) ?>').on( 'click', 'li', function() {
		  var filterValue = $(this).attr('data-filter');
		  $container.isotope({ filter: filterValue });
		});
		
    	  $('.port-filter-group-<?php echo esc_attr($idpro) ?>').each( function( i, buttonGroup ) {
    		var $buttonGroup = $( buttonGroup );
    		$buttonGroup.on( 'click', 'li', function() {
    		  $buttonGroup.find('.is-checked').removeClass('is-checked');
    		  $( this ).addClass('is-checked');
    		});
    	  });
		<?php endif ?>
		
		<?php if($team_pagination == 'load_more' || $team_pagination == 'infinite_pro' ): ?>
		/* Begin Infinite Scroll */
		$container.infinitescroll({
			errorCallback: function(){  $('#infinite-nav-pro').delay(500).fadeOut(500, function(){ $(this).remove(); }); },
		  navSelector  : '#infinite-nav-pro',    // selector for the paged navigation 
		  nextSelector : '.nav-previous a',  // selector for the NEXT link (to page 2)
		  itemSelector : '.progression-masonry-item',     // selector for all items you'll retrieve
	   		loading: {
	   		 	img: '<?php echo esc_url( get_template_directory_uri() );?>/images/loader.gif',
	   			 msgText: "",
	   		 	finishedMsg: "<div id='no-more-posts'><?php esc_html_e( "No more posts", "invested-progression" ); ?></div>",
	   		 	speed: 0, }
		  },
		  // trigger Isotope as a callback
		  function( newElements ) {

		    var $newElems = $( newElements );

				$newElems.imagesLoaded(function(){
					$(".progression-masonry-item").addClass('opacity-progression');
				    $container.isotope( 'appended', $newElems );

			});

		  }
		);
	    /* END Infinite Scroll */
		<?php endif; ?>
		
		
		<?php if($team_pagination == 'load_more'): ?>
		/* PAUSE FOR LAOD MORE */
		$(window).unbind('.infscr');
		// Resume Infinite Scroll
		$('.nav-previous a').click(function(){
			$container.infinitescroll('retrieve');
			return false;
		});
		/* End Infinite Scroll */
		<?php endif; ?>
		
	});
	</script>
	<div class="clearfix-pro"></div>
	
	
	<?php if($team_pagination == 'default'): ?>
		<?php progression_show_pagination_links_blog(); ?>
	<?php endif ?>
	
	
	<?php if($team_pagination == 'load_more'): ?>
		<?php if ( $blogloop->max_num_pages > 1 ) : ?>
			<div id="load-more-manual"><div id="infinite-nav-pro"><div class="nav-previous"><?php next_posts_link( __( 'Load More', 'pro-elements' ), $blogloop->max_num_pages ); ?></div></div></div>
		<?php endif ?>
	<?php endif ?>
	
	
	<?php if($team_pagination == 'infinite_pro'): ?>
		<?php if ( $blogloop->max_num_pages > 1 ) : ?><div id="infinite-nav-pro"><div class="nav-previous"><?php next_posts_link( __( 'Load More', 'pro-elements' ), $blogloop->max_num_pages ); ?></div></div><?php endif ?>
	<?php endif ?>
	
	
	<?php wp_reset_query(); ?>

	<?php
	
	return $output_pro. ob_get_clean();
	
}


add_action( 'vc_before_init', 'progression_team_integrateVC' );
function progression_team_integrateVC() {
   vc_map( array(
      "name" => __( "Pro Team", "pro-elements" ),
	  "description" => __( "List of Team posts", "pro-elements" ),
      "base" => "progression_team",
	  "weight" => 100,
      "class" => "",
      "category" => __( "Pro Elements", "pro-elements"),
	  'icon' => 'vc-icon',

      "params" => array(

		 
         array(
            "type" => "dropdown",
			"class" => "",
            "heading" => __( "Team Columns", "pro-elements" ),
            "param_name" => "team_columns",
			"value"       => array(
			        '1 Column'   	=> '1',
			        '2 Columns'  	=> '2',
			        '3 Columns'		=> '3',
			        '4 Columns'  	=> '4',
					  '5 Columns'  	=> '5',
			),
			"std"         => '3',
         ),
		 	
			
         array(
            "type" => "dropdown",
			"class" => "",
            "heading" => __( "Team Padding", "pro-elements" ),
            "param_name" => "team_padding",
			"value"       => array(
						'0%'				=> '0',
						'1%'				=> '1',
						'2%'				=> '2',
						'3%'				=> '3',
						'4%'				=> '4',
						'5%'				=> '5',
						'6%'				=> '6',
						'7%'				=> '7',
						'8%'				=> '8',
						'9%'				=> '9',
						'10%'				=> '10',
			     
			),
			"std" => "0",
         ),
			
		 
         array(
            "type" => "textfield",
			"class" => "",
            "heading" => __( "Team Post Count", "pro-elements" ),
            "param_name" => "team_post_count",
			"std"         => '9',
         ),
			



         array(
            "type" => "dropdown",
			"class" => "",
            "heading" => __( "Team Pagination", "pro-elements" ),
            "param_name" => "team_pagination",
			"value"       => array(
						__( "No Pagination", "pro-elements" )				=> 'pagination_off',
			        __( "Default Pagination", "pro-elements" )   	=> 'default',
			        __( "Load More Posts", "pro-elements" )  	=> 'load_more',
					  __( "Infinite Scroll", "pro-elements" )  	=> 'infinite_pro'
			),
			"std" => "pagination_off",
         ),
         

        
			
         array(
            "type" => "textfield",
			"class" => "",
            "heading" => __( "Narrow by Team Category", "pro-elements" ),
			"description" => __( "Enter team Category slugs to display a specific category. Add-in multiple slugs seperated by a comma to use multiple categories. (Leave blank to pull in all posts).", "pro-elements" ),
            "param_name" => "property_filter_categories",
			"std"         => '',
         ),
			
			
			
         array(
            "type" => "checkbox",
			"class" => "",
            "heading" => __( "Display Team Sorting?", "pro-elements" ),
            "param_name" => "team_sorting_pro",
			"std"         => 'false',
         ),
			
         array(
            "type" => "textfield",
			"class" => "",
            "heading" => __( "Category Filter Text for All Posts", "qube-elements" ),
            "param_name" => "team_filter_text",
			"std"         => 'All',
			'dependency' => array(
				'element' => 'team_sorting_pro',
				'not_empty' => true,
			),
         ),


         
			
			
			
		
			
         
			
      )
   ) );
}